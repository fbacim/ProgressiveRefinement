﻿import viz

# Load a model
model = viz.addChild('mini.osgx')

# Save to IVE format
model.save('mini.ive')